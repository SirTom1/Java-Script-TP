let clickadd = document.getElementById('clickadd')
let  DisJus   = document.querySelector("#DisJus");

let  DisJus2   = document.querySelector(".DisJus2");
let  DisJus3   = document.querySelector(".DisJus3");
let  DisJus4   = document.querySelector(".DisJus4");
let  DisJus5   = document.querySelector(".DisJus5");

let start_nbr = document.getElementById('start_nbr');
let zero = 0;
start_nbr.innerText = zero;

let carteun;
let cartedeux;

let carte_return = 'assets/img/dos.png';

let tablo = {
            1 : "assets/img/bilgewater.png", // 1
            2 : "assets/img/demacia.png",  // 2
            3 : "assets/img/freljord.png", // 3
            4 : "assets/img/ionia.png",  // 4
            5 : "assets/img/ixtal.png",  // 5
            6 : "assets/img/piltover.png", // 6
            7 : "assets/img/shadow-isles.png", // 7
            8 : "assets/img/shurima.png", // 8
            9 : "assets/img/targon.png", // 9
            10: "assets/img/zaun.png" // 10        
}
console.log(tablo.bilgewater)

let tabloun = [ 1 ,1 , 2 ,2 , 3,3, 4,4, 5,5, 6, 6, 7,7, 8,8, 9, 9, 10, 10];


function getRandomInt() {
    let keys = Object.keys(tablo)
    let prop = keys[Math.floor(Math.random() * keys.length)]
    console.log(prop); 
    
   
  }
  
        

function add(pchitpchit) {
    zero += pchitpchit;
    start_nbr.innerText = zero;

}

function show() {
    DisJus2.style.display = "flex"; 
    DisJus3.style.display = "flex"; 
    DisJus4.style.display = "flex"; 
    DisJus5.style.display = "flex"; 
    DisJus.style.display = "none";
    getRandomInt();
}

clickadd.addEventListener('click', show);



function confirmation(){
    if(carteun.src === cartedeux.src){
        alert('Gagnez')
        add(1);
    }else{
        alert('perdu')
        carteun.src = carte_return;
        cartedeux.src = carte_return;

    }
}


